# GLPI support

Looking for help on usage, capabilities or even configuration of your GLPI instance?

You can ask on:
- [GLPI forums](https://forum.glpi-project.org),
- [GLPI Telegram channel](https://t.me/glpien),
- [GLPI IRC channel](http://webchat.freenode.net/?channels=glpi) #glpi on Freenode,
- Subscribe to one of [GLPI mailing lists](https://glpi-project.org/community).

You may also be looking for [GLPI documentation](https://glpi-project.org/resources/#documentation).
